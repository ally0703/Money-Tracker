# Earnings Tracker

This is a Progressive Web App (PWA), so once it is hosted on an HTTPS website you can add it to your Android home screen and use it like an app.

On Android/Chrome:
1. Open the hosted `index.html`/site.
2. Tap the browser menu (⋮).
3. Choose **Add to Home screen** or **Install app**.
4. Confirm.

The app stores earnings locally in the browser.
